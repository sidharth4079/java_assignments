package guidedDay32;
import java.util.*;

public class LinkedListOperation {
	public static void main(String []args) {
	LinkedList<String> linkedli = new LinkedList<String>();

		linkedli.add("C");
		linkedli.add("C++");
		linkedli.add("C#");
		linkedli.add("COBOL");
		System.out.println("LinkedList: "+ linkedli);

		linkedli.addFirst("Python"); // addFirst() 
		System.out.println("Using addFirst in LinkedList: "+ linkedli);
		
		linkedli.addLast("Java");  //addLast()
		System.out.println("Using addlast in LinkedList: "+ linkedli);
		
		LinkedList<String> linkedli2 = new LinkedList<String>();
		linkedli2.addAll(linkedli); //addAll()
		System.out.println("Using addAll in linkedli2: "+ linkedli2);
		
		System.out.println("size of LinkedList: "+ linkedli.size()); // size()
		
		System.out.println("Finding index: "+ linkedli.indexOf("COBOL")); // indexOf()
		
		System.out.println("Finding last index of first linkedlist: "+ linkedli.lastIndexOf("COBOL"));
		System.out.println("Finding last index of first linkedlist: "+ linkedli2.lastIndexOf("Python")); //lastIndexof()
		
		System.out.println("Peek First: "+ linkedli.peekFirst()); //peekFirst()
		
		System.out.println("Peek Last: "+ linkedli.peekLast()); //peekLast()
		
		System.out.println("Before Poll First: "+ linkedli);
		System.out.println("Poll First: "+ linkedli.pollFirst()); //pollFirst()
		System.out.println("After Poll First: "+ linkedli);
		
		System.out.println("Before Poll Last: "+ linkedli);
		System.out.println("Poll Last: "+ linkedli.pollLast()); //peekFirst()
		System.out.println("After Poll Last: "+ linkedli);
		
		
}
}
