package mankatha;

import java.util.*;

public class Deck {
	public static final int DECK_SIZE = 52;
	List<String> deck = new ArrayList<String>();
		  
	public List<String> shuffle() {
		String[] suit = "H,D,C,S".split(",");
		String[] vals = "A,2,3,4,5,6,7,8,9,10,J,Q,K".split(",");

	    for(String s:suit)
		    for(String v:vals)
		        deck.add(s + v);
	    Collections.shuffle(deck);
	    return deck;

	}
	
	
	public void deal() {
		
	}
}
