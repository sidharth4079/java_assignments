create database E_Commerce;
use E_Commerce;

create table Product(id bigint primary key,
sku VARCHAR(255),
name VARCHAR(255),
description VARCHAR(255),
unitprice DECIMAL(13,2),
imageurl VARCHAR(255),
unitsinstock int,
datecreated DATETIME(6),
lastupdated DATETIME(6),
categoryid bigint,
foreign key(categoryid) references Productcategory(categoryid)
);
desc product;

alter table Product modify datecreated date;
alter table Product modify lastupdated date;
alter table Product modify datecreated varchar(30);
alter table Product modify lastupdated varchar(30);

alter table Product rename column product_name to name;

desc Product;

drop table Product;
select * from Product;

insert into Product values(101,"Bonn","Bread","Best quality and fresh breads Oats", 29.99,"https://www.bigbasket.com/media/uploads/p/l/40051012_8-bonn-bread-multigrain.jpg",26,"2020-07-23","2022-07-26",1101);
insert into Product values(102,"Boat","HeadPhones","Long-life Battery", 1999.99,"https://cdn1.smartprix.com/rx-iybx5LieJ-w1200-h1200/ybx5LieJ.jpg",24,"2017-12-25","2021-09-12",1102);
insert into Product values(103,"Adidas","Tshirt","Good quality", 700,"https://photos6.spartoo.eu/photos/764/7646428/7646428_500_A.jpg",57,"2018-08-25","2022-01-22",1103);


create table Productcategory(categoryid bigint primary key,
categoryname VARCHAR(255)
);

desc table Product;

insert into Productcategory values(1101, "Grocery");
insert into Productcategory values(1103, "Clothing");
insert into Productcategory values(1102, "Electronics");



select * from Productcategory;