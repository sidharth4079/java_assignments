package mankatha;

public class Player {
	private int betValue;
	private String chosenCard;
	private String chosenOrientation;
	
	public Player() {}
	
	public Player(int betValue, String chosenCard, String chosenOrientation) {
		super();
		this.betValue = betValue;
		this.chosenCard = chosenCard;
		this.chosenOrientation = chosenOrientation;
	}
	
	protected int getBetValue() {
		return betValue;
	}

	protected void setBetValue(int betValue) {
		this.betValue = betValue;
	}

	protected String getChosenCard() {
		return chosenCard;
	}

	protected void setChosenCard(String chosenCard) {
		this.chosenCard = chosenCard;
	}

	protected String getChosenOrientation() {
		return chosenOrientation;
	}

	protected void setChosenOrientation(String chosenOrientation) {
		this.chosenOrientation = chosenOrientation;
	}

	
	
}
