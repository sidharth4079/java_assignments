package guidedDay32;

import java.util.*;

public class MovieMain {
	public static void main(String args[]) {
		ArrayList<Movie> mov = new ArrayList<Movie>();
		Movie m1 = new Movie("Mechanic: Resurrection","Dennis Gansel", 98, 2016);
		Movie m2 = new Movie("Wrath of Man","Guy Ritchie", 118, 2021);
		Movie m3 = new Movie("3 Idiots","Rajkumar Hirani", 171, 2009);
		Movie m4 = new Movie("Sanju","Rajkumar Hirani", 155, 2018);
		Movie m5 = new Movie("Men in Black III","Barry Sonnenfeld", 106, 2016);
		Movie m6 = new Movie("Sultan","Kabir Khan", 125, 2016);
		Movie m7 = new Movie("The Wave","Dennis Gansel", 108, 2008);
		Movie m8 = new Movie("83","Kabir Khan", 165, 2021);
		Movie m9 = new Movie("Men in Black","Barry Sonnenfeld", 98, 1997);
		Movie m10 = new Movie("Phantom","Kabir Khan", 136, 2015);
		
		List<Movie> movieList=new ArrayList<Movie>();
		
		movieList.add(m1);
		movieList.add(m2);
		movieList.add(m3);
		movieList.add(m4);
		movieList.add(m5);
		movieList.add(m6);
		movieList.add(m7);
		movieList.add(m8);
		movieList.add(m9);
		movieList.add(m10);
		
		Map<String, List<String>> movieDirectorNames = new HashMap<String,List<String>>();
		
		for(Movie m: movieList) {
			List<String> allMoviesName = new ArrayList<String>();
			allMoviesName.add(m.getName());
			if(movieDirectorNames.containsKey(m.getDirectorName()))
				movieDirectorNames.get(m.getDirectorName()).add(m.getName());
			else
				movieDirectorNames.put(m.getDirectorName(),allMoviesName);
		}
		
		for(Map.Entry m: movieDirectorNames.entrySet()) {
			System.out.println(m.getKey()+ ": "+ m.getValue());
		}
		
	}
}
