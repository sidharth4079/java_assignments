package guidedDay32;

public class IsEmpty {
	
}
