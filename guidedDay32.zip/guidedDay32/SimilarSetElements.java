package guidedDay32;
import java.util.*;

public class SimilarSetElements {
	public static void main(String args[]) {
		Set<Integer> set1 = new HashSet<Integer>();
		set1.addAll(Arrays.asList(new Integer[] { 1, 2, 3, 4, 5, 6}));
		
		Set<Integer> set2 = new HashSet<Integer>();
		set2.addAll(Arrays.asList(new Integer[] { 3, 4, 5, 6, 7 ,8}));
		
		set1.retainAll(set2);
		
		System.out.println(set1);
	}
}
