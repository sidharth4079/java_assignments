package mankatha;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Game {
	public static void main(String args[]) {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("do you want to play the game, enter y for yes or n for no: ");
		String response = sc.nextLine();
		
		boolean flag = true;
		if(response.equals("y")) {
			flag = true;
		}
		else
			flag = false;
		
		while(flag) {
		System.out.println("enter players name");
		System.out.println("enter first player name: ");
		String firstName = sc.nextLine();
		
		System.out.println("enter second player name: ");
		String secondName = sc.nextLine();
		
		System.out.println("enter third player name: ");
		String thirdName = sc.nextLine();
		
		List<String> playerNames = new ArrayList<String>();
		playerNames.add(firstName);
		playerNames.add(secondName);
		playerNames.add(thirdName);
		Collections.shuffle(playerNames);
		
		List<String> host = new ArrayList<String>();
		List<String> playing = new ArrayList<String>();
		
		for(int i=0; i<2; i++) {
			playing.add(playerNames.get(i));
		}
		host.add(playerNames.get(2));
		
		System.out.println(playing.get(0) + " you're the first player");
		System.out.println(playing.get(1) + " you're the second player");
		System.out.println(host.get(0) + " you're the host");
		
		System.out.println(playing.get(0)+" choose your card number(e.g. 1 for Ace ,2 for two etc )");
		int firstCardNum = sc.nextInt();
		System.out.println(playing.get(0)+" choose your suit(e.g. 1-S,2-H,3-D,4-C)");
		int firstSuit = sc.nextInt();
		Card c1 = new Card(firstCardNum, firstSuit);
		System.out.println(playing.get(0)+" your card is "+ c1.toString());
		
		
		System.out.println(playing.get(1)+" choose your card number(e.g. 1 for Ace ,2 for two etc )");
		int secondCardNum = sc.nextInt();
		System.out.println(playing.get(1)+" choose your suit(e.g. 1-S,2-H,3-D,4-C)");
		int secondSuit = sc.nextInt();
		Card c2 = new Card(secondCardNum, secondSuit);
		System.out.println(playing.get(1)+" your card is "+ c2.toString());
				
		System.out.println(playing.get(0)+" enter your bet amount");
		int firstBet = sc.nextInt();
		sc.nextLine();
		System.out.println(playing.get(0)+" choose your orientation(i.e in or out)");
		String firstOrientation = sc.nextLine();
		Player p1 = new Player(firstBet,c1.toString(),firstOrientation);
				
		System.out.println(playing.get(1)+" enter your bet amount");
		int secondBet = sc.nextInt();
		sc.nextLine();
		System.out.println(playing.get(1)+" choose your orientation(i.e in or out)");
		String secondOrientation = sc.nextLine();
		Player p2 = new Player(secondBet,c2.toString(),secondOrientation);		
		
		List<String> inOrientationCards = new ArrayList<String>();
		List<String> outOrientationCards = new ArrayList<String>();
		
		Deck d = new Deck();
		int counter=0;
		int x = 26;
		
		for(int i = 0; i < x; i++){
			inOrientationCards.add(d.shuffle().get(i));
		    outOrientationCards.add(d.shuffle().get(i));
		}	    
		
		    for(int j=0; j< inOrientationCards.size();j++)
		    {
		    	
		    	if(Card.compareCards(c1.toString(),inOrientationCards.get(j)) && p1.getChosenOrientation().equals("in"))
		    	{
		    		System.out.println(playing.get(0) +" wins " + (p1.getBetValue()+p2.getBetValue()));
		    		counter=1;
		    		break;
		    	}
		    	
		    	else if(Card.compareCards(c1.toString(),outOrientationCards.get(j)) && p1.getChosenOrientation().equals("out"))
		    	{
		    		System.out.println(playing.get(0) +" wins " + (p1.getBetValue()+p2.getBetValue()));
		    		counter=1;
		    		break;
		    	}
		    	
		    	else if(Card.compareCards(c2.toString(),inOrientationCards.get(j)) && p2.getChosenOrientation().equals("in"))
		    	{
		    		System.out.println(playing.get(1) +" wins " + (p1.getBetValue()+p2.getBetValue()));
		    		counter=1;
		    		break;
		    	}
		    	
		    	else if(Card.compareCards(c2.toString(),outOrientationCards.get(j)) && p2.getChosenOrientation().equals("out"))
		    	{
		    		System.out.println(playing.get(1) +" wins " + (p1.getBetValue()+p2.getBetValue()));
		    		counter=1;
		    		break;
		    	}
		    }			
			
		if(counter == 0)
	    	System.out.println(host.get(0)+" wins "+(p1.getBetValue()+p2.getBetValue()));
	    
	    System.out.println("do you want to play the game, enter y for yes or n for no: ");
		String response2 = sc.nextLine();
		if(response2.equals("y")) {
			flag = true;
		}
			else
				flag = false;
		}
	}
	}


