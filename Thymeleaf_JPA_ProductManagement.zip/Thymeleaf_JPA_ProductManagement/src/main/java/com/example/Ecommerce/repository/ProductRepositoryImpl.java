package com.example.Ecommerce.repository;

public class ProductRepositoryImpl {

}
