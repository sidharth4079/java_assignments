package guidedDay32;
import java.util.*;
//import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.*;

public class ArrayListOperations {
	public static void main(String []args) {
			ArrayList<String> arrli = new ArrayList<String>();
			arrli.add("C");
			arrli.add("C++");
			arrli.add("Java");
			arrli.add("Python");
				
				
			System.out.println("Size of the ArrayList is: " + arrli.size());
			System.out.println("ArrayList is Empty: " + arrli.isEmpty());
			System.out.println("ArrayList at index 0: " + arrli.get(0));
			
			arrli.set(3,"Python3");
			System.out.println("ArrayList After changes: " + arrli);
			
			System.out.println("Before Appending the List: "+ arrli);
			arrli.add("R");
			arrli.add("MySQL");
			arrli.add("save");
			arrli.add("vase");
			System.out.println("After Appending the List: "+ arrli);
			
			System.out.println("Anagram List: " + getAnagram(arrli));
			}
	
	public static ArrayList getAnagram(ArrayList a1) {
		ArrayList<String> anagList = new ArrayList<String>();
		for(int i=0; i< a1.size()-1; i++)
		{
			for(int j=i+1; j<a1.size(); j++)
			{	
				char []str1 = ((String) a1.get(i)).toCharArray();
				char []str2 = ((String) a1.get(j)).toCharArray();
				Arrays.sort(str1);
				Arrays.sort(str2);
		        if(Arrays.equals(str1,str2)) {
		        	anagList.add((String) a1.get(i));
		        	anagList.add((String) a1.get(j));
		        }
			}
		}
		return anagList;
	}
	
	}
